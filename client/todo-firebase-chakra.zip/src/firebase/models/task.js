import { collection, doc, getDocs, query, where } from "firebase/firestore";
import { db } from "../firebase";

const tasksCollection = collection(db, "todo");

export const createTask = async (todo) => {
  try {
    await tasksCollection.add(todo);
  } catch (error) {
    console.error("Error creating todo", error);
  }
};

export const updateTask = async (taskId, updatedTask) => {
  try {
    await tasksCollection.doc(taskId).update(updatedTask);
  } catch (error) {
    console.error("Error updating todo", error);
  }
};

export const deleteTask = async (taskId) => {
  try {
    const docRef = doc(tasksCollection);
    await tasksCollection.doc(taskId).delete();
  } catch (error) {
    console.error("Error deleting todo", error);
  }
};

export const getTasks = async (task_name) => {
  try {
    const tasksCol = query(collection(db, "todo"), where("task_name", "==", task_name));
    const taskSnapshot = await getDocs(tasksCol);
    const taskList = taskSnapshot.docs.map((doc) => doc.data());
    return taskList;
  } catch (error) {
    console.error("Error getting tasks", error);
    return [];
  }
};
