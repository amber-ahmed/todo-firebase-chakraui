import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom'
import Landing from './jsx/views/Landing'
import Dashboard from './jsx/views/Dashboard'
import RootLayout from './jsx/layouts/RootLayout'
import Login from './jsx/views/authentications/Login'
import Register from './jsx/views/authentications/Register'

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<RootLayout />} >
      <Route index element={<Landing />} />
      <Route path='login' element={<Login/>}/>
      <Route path='register' element={<Register/>}/>
      <Route path='dashboard' element={<Dashboard />} />
    </Route>
  )
)

function App() {


  return (
    <RouterProvider router={router} />
  )
}

export default App
