import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import { ChakraProvider, extendTheme } from '@chakra-ui/react';
import colors from './themes/theme.jsx';
import ThemeContext from './contexts/ThemeContext.js';


function Root() {
  const selectedTheme = localStorage.getItem('theme');
  const [userTheme, setUserTheme] = useState(selectedTheme || 'rainbow');

  const theme = extendTheme({
    colors: userTheme === 'light' ? colors.light : userTheme === 'dark' ? colors.dark : colors.rainbow,
    styles: {
      global: {
        body: {
          width: '100%',
          height: '100%',
          margin: 0,
          padding: 0,
          bg: 'primary',
        },
      },
    },
  });

  return (
    <ThemeContext.Provider value={setUserTheme}>
      <ChakraProvider theme={theme}>
        <App />
      </ChakraProvider>
    </ThemeContext.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root />);