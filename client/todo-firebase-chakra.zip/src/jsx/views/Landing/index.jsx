import { Heading } from '@chakra-ui/react'
import React from 'react'

const Landing = () => {
    return (
        <Heading>Hello</Heading>
    )
}

export default Landing
