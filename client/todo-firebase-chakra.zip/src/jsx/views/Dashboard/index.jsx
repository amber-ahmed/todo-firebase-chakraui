import React, { useEffect } from 'react'
import AddTask from './AddTask'
import TodoList from './TodoList';
import { getTasks } from '../../../firebase/models/task';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '../../../firebase/firebase';

const Dashboard = () => {

  // useEffect(() => {
  //   const tasksCollection = collection(db, "todo");
  //   const unSubscribe = onSnapshot(
  //     query(tasksCollection),
  //     (snapshot) => {
  //       const tasks = snapshot.docs.map((doc) => {
  //         console.log({ id: doc.id, ...doc.data() });
  //         return { id: doc.id, ...doc.data() };
  //       });
  //       // Use 'tasks' as needed, for example, set it in the component state
  //     }
  //   );
  
  //   return unSubscribe;
  // }, []);
  
  useEffect(() => {
    getTasks('meeting')
      .then((tasksFromFirestore) => {
        console.log('Tasks from Firestore:', tasksFromFirestore);
      })
      .catch((error) => {
        console.error('Error fetching tasks:', error);
      });
  }, []);
  return (
    <>


      <TodoList />
      <AddTask />
    </>
  )
}

export default Dashboard
