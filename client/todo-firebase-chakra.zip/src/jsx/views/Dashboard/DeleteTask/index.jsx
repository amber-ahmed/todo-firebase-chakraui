import React from 'react'
import Alert from '../../../components/Alert'
import { IconButton, useDisclosure } from '@chakra-ui/react'
import { DeleteIcon } from '@chakra-ui/icons'

const DeleteTask = () => {
    const { isOpen, onOpen, onClose } = useDisclosure()
    const deleteTask = ()=>{
        console.log('delete')
        onClose()
    }
    return (
        <>
            <Alert title='Delete Task' description='Are you sure' okFun={deleteTask} isOpen={isOpen} onClose={onClose} okText='Delete' buttonColor='red' />
            <IconButton
                icon={<DeleteIcon />}
                onClick={onOpen}
                size={'sm'}
                bg={'text2'}
                isRound='true'
                mr={4}
            />
        </>
    )
}

export default DeleteTask
