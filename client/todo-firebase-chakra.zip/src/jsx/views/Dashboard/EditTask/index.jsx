import React from 'react'
import { FormControl, FormErrorMessage, FormHelperText, FormLabel, IconButton, Input, } from '@chakra-ui/react'
import CustomModal from '../../../components/CustomModal'
import { useDisclosure } from '@chakra-ui/react'
import { EditIcon } from '@chakra-ui/icons'
import { useForm } from 'react-hook-form'

const ModalBody = ({ register, errors }) => {
    return (
        <FormControl isInvalid={errors.taskName}>
            <FormLabel htmlFor='taskName'>Task Name</FormLabel>
            <Input
                id='taskName'
                placeholder='Task Name'
                {...register('taskName', {
                    required: 'This is required'
                })}
            />
            <FormErrorMessage>
                {errors.taskName && errors.taskName.message}
            </FormErrorMessage>
        </FormControl>
    )
}
const UpdateTask = () => {
    const { isOpen, onOpen, onClose } = useDisclosure()
    const {
        register,
        reset,
        formState: { errors },
        getValues,
        handleSubmit,
    } = useForm({ criteriaMode: "all", mode: "all" });


    const updateTask = () => {
        try {
            console.log(getValues('taskName'))
            reset()
            onClose();
        } catch (error) {
            console.error(error);
        }
    }
    return (
        <>
            <form>


                <CustomModal isOpen={isOpen} onClose={onClose} title={'Update Task'} modalBody={<ModalBody register={register} errors={errors} />} okText={'Update'} okFunction={handleSubmit(updateTask)} />
                <IconButton
                    onClick={onOpen}
                    icon={<EditIcon />}
                    size={'sm'}
                    bg={'text2'}
                    isRound='true'
                />
            </form>
        </>
    )
}

export default UpdateTask
