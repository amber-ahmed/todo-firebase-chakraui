import { ListItem, List, Flex, Text, Card,Checkbox  } from "@chakra-ui/react";
import React, { useMemo, useState } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import EditTask from "../EditTask";
import DeleteTask from "../DeleteTask";

const TodoList = () => {
  const [todos, setTodos] = useState([
    { id: 1, name: "meeting" },
    { id: 2, name: "party" },
  ]);
  const reorder = useMemo(
    () => (startIndex, endIndex) => {
      let result = Array.from(todos);
      const [removed] = result.splice(startIndex, 1);
      result.splice(endIndex, 0, removed);
      result = result.map((ele, index) => {
        return { ...ele, order: index };
      });
      return result;
    },
    [todos]
  );
  const onDragEnd = (result) => {
    console.log(result);
    if (!result.destination || result.source.index === result.destination.index)
      return;
    const reorderedItems = reorder(
      result.source.index,
      result.destination.index
    );
    setTodos(reorderedItems);
  };
  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <List>
        <Droppable droppableId="droppable">
          {(provided, snapshot) => (
            <div
              className=""
              {...provided.droppableProps}
              ref={provided.innerRef}
            >
              {todos.map((todo, index) => (
                <Draggable
                  key={todo.id}
                  draggableId={todo.id.toString()}
                  index={index}
                >
                  {(provided) => (
                    <div
                      key={todo.id}
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                    >
                      <Card
                        width={"75%"}
                        marginX="auto"
                        sx={{ marginY: 2, bg: "secondary", boxShadow: "lg" }}
                      >
                        <ListItem>
                          <Flex justifyContent={"space-between"}>
                            <Flex padding={2} justifyContent={"space-around"}>
                              <Checkbox checked={todo.status}/>
                              <Text sx={{ color: "primary", padding: 2 }}>
                                {todo.name}
                              </Text>
                            </Flex>
                            <Flex padding={2} justifyContent={"space-around"}>
                              <DeleteTask />
                              <EditTask />
                            </Flex>
                          </Flex>
                        </ListItem>
                      </Card>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </List>
    </DragDropContext>
  );
};

export default TodoList;
